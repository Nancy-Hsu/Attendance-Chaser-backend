const jwt = require('jsonwebtoken')

const { User } = require('../models')
require('express-async-errors');
const usersServices = {
  logIn: async (req, next) => {
  }
}
module.exports = usersServices